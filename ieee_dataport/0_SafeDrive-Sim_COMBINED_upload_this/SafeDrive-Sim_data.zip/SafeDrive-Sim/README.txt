SafeDrive-Sim: SYNTHETIC data (no real drivers, vehicles, people or crashes). See SafeDrive-Sim_documentation.pdf.
1_driver_behavior_imu/   12 trips of simulated smartphone IMU data + labelled events
2_alcohol_sensors/       2,000 simulated sessions, 5 sensor features + label
3_crash_records/         30,000 simulated crash records (Coimbatore-area bounding box)
